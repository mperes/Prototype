package artcom.tween;

import java.lang.reflect.*;
import java.lang.reflect.Method;
import processing.core.*;

public class Tween {
	public PApplet _parentPApplet;
	public Object _parentObject;
	Field _field;
	float _start;
	float _end;
	float _currentValue;
	int _duration;
	public Method _onFinishCallback;
	float _increment;
	int _currentFrame;
	boolean _finished;

	Tween(Object __parent, String __tweenField, float __tweenV0, float __tweenV1, int __tweenDuration) {
		_parentObject = __parent;
		try { _field = _parentObject.getClass().getField(__tweenField); } 
		catch (Exception e) { System.out.println("Ivalid Field"); }
		setBasic(__tweenV0, __tweenV1, __tweenDuration);
		updateField();
	}
	
	Tween(Object __parent, String __tweenField, float __tweenV0, float __tweenV1, int __tweenDuration, String __tweenCallback) {
		_parentObject = __parent;
		try { _onFinishCallback = _parentObject.getClass().getMethod(__tweenCallback, new Class[] { Tween.class }); }
		catch (Exception e) { System.out.println("Invalid Method"); }
		try { _field = _parentObject.getClass().getDeclaredField(__tweenField); } 
		catch (Exception e) { System.out.println("Ivalid Field"); }
		setBasic(__tweenV0, __tweenV1, __tweenDuration);
		updateField();
	}	

	void setBasic(float f0, float f1, int d) {
		_start = f0;
		_end = f1;
		_currentValue = f0;
		_duration = d;
		_increment = f1-f0;
		_currentFrame = 0;
		_finished = false;
	}

	void update() {
		if(!_finished) {
			float speed =  (float) (90.0 / _duration);
			if(_currentFrame <= _duration) {
				_currentValue = (float) (_start + Math.sin(Math.toRadians(_currentFrame*speed))*_increment);  
				_currentFrame++;
			} 
			else {
				_finished = true;
			}
		}
	}

	Boolean finished() {
		return _finished;
	}

	float getState() {
		return _currentValue;
	}

	public void onFinish() {
		if (_onFinishCallback != null) {
			try {
				if(_parentPApplet != null) {
					_onFinishCallback.invoke(_parentPApplet, new Object[] { this });
				} 
				else {
					_onFinishCallback.invoke(_parentObject, new Object[] { this });
				}
			} 
			catch (Exception e) {
				e.printStackTrace();
				_onFinishCallback = null;
			}
		}
	}

	
	public void updateField() {
	    try {
	      if(_field.getType().getName() == "float") {
	        if(_parentPApplet != null) {
	          _field.setFloat(_parentPApplet, _currentValue);
	        } else {
	          _field.setFloat(_parentObject, _currentValue);
	        } 
	      }
	      else if(_field.getType().getName() == "int") {
	        if(_parentPApplet != null) {
	          _field.setInt(_parentPApplet, (int)_currentValue);
	        } else {
	          _field.setInt(_parentObject, (int)_currentValue);
	        } 
	      }      
	    } catch (Exception e) { System.out.println("Invalid field. Class must be Public, Field must be Public and of the type float or int."); }
	  }

}