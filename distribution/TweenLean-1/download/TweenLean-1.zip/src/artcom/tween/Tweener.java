/**
 * TweenLean
 * A lightweight animation library with callback support
 * http://www.miguelperes.com/Tweener
 *
 * Copyright (C) 2011 Miguel Peres http://www.miguelperes.com
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General
 * Public License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA  02111-1307  USA
 * 
 * @author      Miguel Peres http://www.miguelperes.com
 * @modified    11/08/2011
 * @version     0.1.1 (1)
 */

package artcom.tween;

import java.util.ArrayList;
import processing.core.*;

public class Tweener {
	PApplet _parent;
	private ArrayList<Tween> _timeline;

	public Tweener(PApplet __parent) {
		_parent = __parent;
		_timeline = new ArrayList<Tween>();
		
		_parent.registerPre(this);
	}

	public void update() {
		for(int t=0; t<_timeline.size(); t++) {
			Tween tween = (Tween)_timeline.get(t);
			tween.update();
			if(tween.finished()) {
				tween.onFinish();
				_timeline.remove(t);
			} 
			else {     
				tween.updateField();
			}
		}
	}
	
	public void tween(Object __parent, String __tweenField, float __tweenV0, float __tweenV1, int __tweenDuration) {
		Tween newTween = new Tween(__parent, __tweenField, __tweenV0, __tweenV1, __tweenDuration);
		_timeline.add(newTween);
	}

	public void tween(Object __parent, String __tweenField, float __tweenV0, float __tweenV1, int __tweenDuration, String __tweenCallback) {
		Tween newTween = new Tween(__parent, __tweenField, __tweenV0, __tweenV1, __tweenDuration, __tweenCallback);
		_timeline.add(newTween);
	}
	
	public void pre() {
		update();
	}

}


