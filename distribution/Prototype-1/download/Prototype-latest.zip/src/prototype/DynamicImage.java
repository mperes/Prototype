package prototype;

public interface DynamicImage {
	public void draw();
}
