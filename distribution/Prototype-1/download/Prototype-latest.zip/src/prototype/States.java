package prototype;

public interface States {
	public final static int DEFAULT = 0;
	public final static int HOVER = 1;
	public final static int PRESSED = 2;
}
