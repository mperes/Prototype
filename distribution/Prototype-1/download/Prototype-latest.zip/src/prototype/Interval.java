package prototype;
public interface Interval {
	void update();
	boolean finished();
	void onFinish();
}
