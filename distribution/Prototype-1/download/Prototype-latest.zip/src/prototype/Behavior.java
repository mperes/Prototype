package prototype;

public interface Behavior {
	void initBehavior(Part parent);
	int type();
}
