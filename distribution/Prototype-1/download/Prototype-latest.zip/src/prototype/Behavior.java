package prototype;

public interface Behavior {
	
}
