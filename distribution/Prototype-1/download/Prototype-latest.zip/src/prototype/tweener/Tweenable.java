package prototype.tweener;

public interface Tweenable {

}