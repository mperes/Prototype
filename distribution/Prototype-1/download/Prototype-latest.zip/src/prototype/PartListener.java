package prototype;

public interface PartListener {
	public void partUpdated(PartUpdateEvent event);
}
