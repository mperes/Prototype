package prototype;
public interface Tweenable {

}
