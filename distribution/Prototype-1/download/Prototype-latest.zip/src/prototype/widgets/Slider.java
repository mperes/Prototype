package prototype.widgets;

import processing.core.*;
import prototype.*;

public class Slider extends ImagePart {

	public Slider(Skin blueprint) {
		super(blueprint);
		// TODO Auto-generated constructor stub
	}

}
