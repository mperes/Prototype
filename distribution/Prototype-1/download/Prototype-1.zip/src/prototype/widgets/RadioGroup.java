package prototype.widgets;

import prototype.Part;

public class RadioGroup {
	
	public RadioGroup(int width, int margin, String...strings) {
		//super();
		for(String label : strings) {
			
		}
	}

}
