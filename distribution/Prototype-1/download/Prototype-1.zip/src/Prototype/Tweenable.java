package Prototype;
public interface Tweenable {

}
