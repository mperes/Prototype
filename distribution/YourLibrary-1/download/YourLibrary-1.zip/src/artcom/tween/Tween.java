package artcom.tween;

import java.lang.reflect.*;
import java.lang.reflect.Method;
import processing.core.*;

public class Tween {
	PApplet _parentPApplet;
	Tweenable _parentObject;
	Field _field;
	float _start;
	float _end;
	float _currentValue;
	int _duration;
	Method _onFinishCallback;
	float _increment;
	int _currentFrame;
	boolean _finished;

	Tween(PApplet parent, String tweenField, float tweenV0, float tweenV1, int tweenDuration, String tweenCallback) {
		_parentPApplet = parent;
		try { _onFinishCallback = _parentPApplet.getClass().getMethod(tweenCallback, new Class[] { Tween.class }); }
		catch (Exception e) { System.out.println("Method Error"); }
		try { _field = _parentPApplet.getClass().getField(tweenField); } 
		catch (Exception e) { System.out.println("Field Error"); }
		setBasic(tweenField, tweenV0, tweenV1, tweenDuration);
		updateField();
	}

	Tween(Tweenable parent, String tweenField, float tweenV0, float tweenV1, int tweenDuration, String tweenCallback) {
		_parentObject = parent;
		try { _onFinishCallback = _parentObject.getClass().getMethod(tweenCallback, new Class[] { Tween.class }); }
		catch (Exception e) { System.out.println("Method Error"); }
		try { _field = _parentObject.getClass().getDeclaredField(tweenField); } 
		catch (Exception e) { System.out.println("Field Error"); }
		setBasic(tweenField, tweenV0, tweenV1, tweenDuration);
		updateField();
	}

	Tween(PApplet parent, String tweenField, float tweenV0, float tweenV1, int tweenDuration) {
		_parentPApplet = parent;
		try { _field = _parentPApplet.getClass().getField(tweenField); } 
		catch (Exception e) { System.out.println("Field Error"); }
		setBasic(tweenField, tweenV0, tweenV1, tweenDuration);
		updateField();
	}

	Tween(Tweenable parent, String tweenField, float tweenV0, float tweenV1, int tweenDuration) {
		_parentObject = parent;
		try { _field = _parentObject.getClass().getDeclaredField(tweenField); } 
		catch (Exception e) { System.out.println("Field Error"); }
		setBasic(tweenField, tweenV0, tweenV1, tweenDuration);
		updateField();
	}

	void setBasic(String s, float f0, float f1, int d) {
		_start = f0;
		_end = f1;
		_currentValue = f0;
		_duration = d;
		_increment = f1-f0;
		_currentFrame = 0;
		_finished = false;
	}

	void update() {
		if(!_finished) {
			float speed =  (float) (90.0 / _duration);
			if(_currentFrame <= _duration) {
				_currentValue = (float) (_start + Math.sin(Math.toRadians(_currentFrame*speed))*_increment);  
				_currentFrame++;
			} 
			else {
				_finished = true;
			}
		}
	}

	Boolean finished() {
		return _finished;
	}

	float getState() {
		return _currentValue;
	}

	public void onFinish() {
		if (_onFinishCallback != null) {
			try {
				if(_parentPApplet != null) {
					_onFinishCallback.invoke(_parentPApplet, new Object[] { this });
				} 
				else {
					_onFinishCallback.invoke(_parentObject, new Object[] { this });
				}
			} 
			catch (Exception e) {
				e.printStackTrace();
				_onFinishCallback = null;
			}
		}
	}

	public void updateField() {
		try {
			if(_field.getType().getName() == "float") {
				if(_parentPApplet != null) {
					_field.setFloat(_parentPApplet, _currentValue);
				} else {
					_field.setFloat(_parentObject, _currentValue);
				} 
			}
			else if(_field.getType().getName() == "int") {
				if(_parentPApplet != null) {
					_field.setInt(_parentPApplet, (int)_currentValue);
				} else {
					_field.setInt(_parentObject, (int)_currentValue);
				} 
			}      
		} catch (Exception e) {}
	}

}