package artcom.tween;

public interface Tweenable {

}
