package littlerobots.tweenermatrix;

public interface Tweenable {

}
