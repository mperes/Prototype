package littlerobots.tweenermatrix;

public interface Interval {
	void update();
	boolean finished();
	void onFinish();
}
