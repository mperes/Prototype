package littlerobots.assemblyline;

import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;

import littlerobots.builderbot.*;
import littlerobots.tweenermatrix.TweenerMatrix;

import processing.core.PApplet;


public class AssemblyLine implements MouseWheelListener {
	private PApplet parent;
	private TweenerMatrix tweenerMatrix;
	private ArrayList<BuilderBot> bots;
	
	public AssemblyLine(PApplet parent) {	
		parent.registerPre(this);
		parent.registerDraw(this);
		parent.registerMouseEvent(this);
		parent.frame.addMouseWheelListener(this);
		
		this.parent = parent;
		bots = new ArrayList<BuilderBot>();
	}

	public void installTweenMatrix(boolean remove) {
		if(!remove && tweenerMatrix != null) {
			tweenerMatrix = new TweenerMatrix();
		} else {
			tweenerMatrix = null;
		}
	}
	
	public BuilderBot addBuilderBot(Blueprint blueprint) {
		BuilderBot newBot = new BuilderBot(parent, blueprint);
		bots.add(newBot);
		return newBot;
	}
	
	public BuilderBot addBuilderBot(Blueprint blueprint, int x, int y) {
		BuilderBot newBot = new BuilderBot(parent, blueprint, x, y);
		bots.add(newBot);
		return newBot;
	}
	
	public void pre(){
		//Updates TweenMatrix
		if(tweenerMatrix != null) {
			tweenerMatrix.update();
		}
		updateBots();
	}
	
	private void updateBots() {
		for(int b=0; b<bots.size(); b++) {
			BuilderBot bot = bots.get(b);
			bot.pre();
		}
	}
	
	public void draw(){
		drawBots();
		//System.out.println("drawing Assembly");
	}
	
	void drawBots() {
		for(int b=0; b < bots.size(); b++) {
			BuilderBot bot = bots.get(b);
			bot.draw();
		}
	}
	
	public void mouseEvent(MouseEvent event) {
		// get the x and y pos of the event
		//int x = event.getX();
		//int y = event.getY();

		switch (event.getID()) {
		case MouseEvent.MOUSE_PRESSED:
			//mousePressed(mouseInside());
			break;
		case MouseEvent.MOUSE_RELEASED:
			//mouseReleased(mouseInside());
			break;
		case MouseEvent.MOUSE_CLICKED:
			//mouseClicked(mouseInside());
			break;
		case MouseEvent.MOUSE_DRAGGED:
			//mouseDragged(mouseInside());
			break;
		case MouseEvent.MOUSE_MOVED:
			//mouseMoved(mouseInside());
			break;
		}
	}
	
	public void mouseWheelMoved(MouseWheelEvent e) {
		//int step = e.getWheelRotation();
		//mouseScrolled(mouseInside(), step);
	}
}
