package littlerobots.builderbot;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PImage;

public class BuilderBot {
	private PApplet parentPApplet;
	private Blueprint blueprint;
	public BuilderBot parent;
	ArrayList<BuilderBot> bots;
	public float x;
	public float y;
	public int width;
	public int height;
	public float scaleX;
	public float scaleY;
	private float pivotX;
	private float pivotY;
	private float left;
	private float top;
	private float right;
	private float bottom;
	boolean visible;
	boolean enabled;
	private float alpha;
	public boolean showPivot;  

	public BuilderBot (PApplet parentPApplet, Blueprint blueprint) {
		initBot(parentPApplet, blueprint);
		x = 0;
		y = 0;
	}

	public BuilderBot (PApplet parentPApplet, Blueprint blueprint,int x, int y) {
		initBot(parentPApplet, blueprint);
		this.x = x;
		this.y = y;
	}

	private void initBot (PApplet parentPApplet, Blueprint blueprint) {
		this.parentPApplet = parentPApplet;
		this.blueprint = blueprint;
		
		width = this.blueprint.initialWidth;
		height = this.blueprint.initialHeight;
		scaleX = this.blueprint.scaleX;
		scaleY = this.blueprint.scaleY;
		setPivot(this.blueprint.pivotX, this.blueprint.pivotY);
		visible = this.blueprint.visible;
		enabled = this.blueprint.enabled;
		alpha = alpha(this.blueprint.alpha);
		showPivot = this.blueprint.showPivot;

		this.blueprint.initBlueprint(this.parentPApplet);
		calcBox();
		readBlueprint();
		
		bots = new ArrayList<BuilderBot>();
	}

	private void calcBox() {
		left = x -  pivotX * width * scaleX;
		top = y - pivotY * height * scaleY;
		right =  left + width * scaleX;
		bottom = top + height * scaleY;
	}

	public void readBlueprint() {
		blueprint.beginDraw();
		blueprint.background(0);
		blueprint.draw();
		blueprint.endDraw();
	}

	public void setPivot(float x, float y) {
		pivotX = PApplet.constrain(x, 0, 1);
		pivotY = PApplet.constrain(y, 0, 1);
	}

	public void draw() {
		parentPApplet.pushMatrix();
		parentPApplet.translate(x, y);
		parentPApplet.pushStyle();
		parentPApplet.tint(255, 255*alpha);
		parentPApplet.image(blueprint, -pivotX*width*scaleX, -pivotY*height*scaleY, width*scaleX, height*scaleY);
		if (showPivot) { 
			drawPivot();
		}
		drawBots();
		parentPApplet.popStyle();
		parentPApplet.popMatrix();
	}

	void drawBots() {
		for(int b=0; b < bots.size(); b++) {
			BuilderBot bot = bots.get(b);
			bot.draw();
		}
	}

	private void drawPivot() {
		parentPApplet.pushStyle();
		parentPApplet.fill(255, 0, 0);
		parentPApplet.noStroke();
		parentPApplet.rectMode(PConstants.CENTER);
		parentPApplet.rect(0, 0, 5, 5);
		parentPApplet.popStyle();
	}

	public void pre() {
		calcBox();
		updateBots();
	}

	void updateBots() {
		for(int b=0; b<bots.size(); b++) {
			BuilderBot bot = bots.get(b);
			bot.pre();
		}
	}

	boolean mouseInside() {
		calcBox();
		return (parentPApplet.mouseX > left && parentPApplet.mouseX < right && parentPApplet.mouseY > top && parentPApplet.mouseY < bottom) ? true : false;
	}

	boolean mouseReallyInside() {
		if (mouseInside()) {
			PImage buffer = blueprint.get();
			buffer.resize(width*(int)scaleX, height*(int)scaleY);
			buffer.loadPixels();
			if (buffer.pixels[PApplet.constrain( (parentPApplet.mouseX-(int)left) + (parentPApplet.mouseY-(int)left) * width, 0, buffer.pixels.length-1)] == 0x00000000) {
				buffer.updatePixels();
				return false;
			}
			buffer.updatePixels();
			return true;    
		}
		return false;
	}

	public BuilderBot addHelperBot(Blueprint blueprint) {
		BuilderBot newBot = new BuilderBot(parentPApplet, blueprint);
		newBot.parent = this;
		bots.add(newBot);
		return newBot;
	}
	
	public BuilderBot addHelperBot(Blueprint blueprint,int x, int y) {
		BuilderBot newBot = new BuilderBot(parentPApplet, blueprint, x, y);
		newBot.parent = this;
		bots.add(newBot);
		return newBot;
	}
	
	public float alpha(float alpha) {
		return alpha = PApplet.constrain(alpha, 0, 1);
	}
	
	public float alpha() {
		return alpha;
	}
}
