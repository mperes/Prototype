package littlerobots.assemblyline.tweenermatrix;

public interface Tweenable {

}
