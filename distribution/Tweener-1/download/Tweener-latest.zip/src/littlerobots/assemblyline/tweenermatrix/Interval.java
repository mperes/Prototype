package littlerobots.assemblyline.tweenermatrix;

public interface Interval {
	void update();
	boolean finished();
	void onFinish();
}
