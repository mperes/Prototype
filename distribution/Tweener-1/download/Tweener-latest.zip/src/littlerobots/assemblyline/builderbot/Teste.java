package littlerobots.assemblyline.builderbot;

public class Teste extends Blueprint{
	
	public Teste() {
		super(10,10);
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		
	}
	
}
