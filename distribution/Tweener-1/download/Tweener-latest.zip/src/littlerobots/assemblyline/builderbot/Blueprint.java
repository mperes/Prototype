package littlerobots.assemblyline.builderbot;

import processing.core.PApplet;
import processing.core.PGraphics;

public abstract class Blueprint extends PGraphics {
	
	final int initialWidth;
	final int initialHeight;
	
	public Blueprint(int initialWidth, int initialHeight) {
		this.initialWidth = initialWidth;
		this.initialHeight = initialHeight;
	}
	
	final void initBlueprint(PApplet parent) {
		setParent(parent);
		setSize(initialWidth, initialHeight);
	}
	
	public abstract void draw();
	
	public void mousePressed(boolean mouseInside) {
	}

	public void mouseReleased(boolean mouseInside) {
	}

	public void mouseClicked(boolean mouseInside) {
	}

	public void mouseDragged(boolean mouseInside) {
	}

	public void mouseMoved(boolean mouseInside) {
	}

	public void mouseScrolled(boolean mouseInside, int step) {
	}

}
