package littlerobots.assemblyline.builderbot;

import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PConstants;
import processing.core.PImage;

public class BuilderBot {
	private PApplet parentPApplet;
	private Blueprint blueprint;
	public BuilderBot parent;
	ArrayList<BuilderBot> bots;
	public float x;
	public float y;
	public int width;
	public int height;
	public float scaleX;
	public float scaleY;
	private float pivotX;
	private float pivotY;
	private float left;
	private float top;
	private float right;
	private float bottom;
	boolean visible;
	boolean enabled;
	float alpha;
	public boolean showPivot;  

	public BuilderBot (PApplet parentPApplet, Blueprint blueprint) {
		this.parentPApplet = parentPApplet;
		this.blueprint = blueprint;
		bots = new ArrayList<BuilderBot>();
		x = 0;
		y = 0;
		width = this.blueprint.initialWidth;
		height = this.blueprint.initialHeight;
		scaleX = 1;
		scaleY = 1;
		setPivot(0, 0);
		visible = true;
		enabled = true;
		alpha = 1;
		showPivot = false;

		this.blueprint.initBlueprint(this.parentPApplet);
		calcBox();
		readBlueprint();
	}

	private void calcBox() {
		float parentX = 0;
		float parentY = 0;
		if (parent != null) {
			parentX = parent.x;
			parentY = parent.y;
		}
		left = parentX + x -  pivotX * width * scaleX;
		top = parentY + y - pivotY * height * scaleY;
		right =  parentX + left + width * scaleX;
		bottom = parentY + top + height * scaleY;
	}

	public void readBlueprint() {
		blueprint.beginDraw();
		blueprint.background(0);
		blueprint.draw();
		blueprint.endDraw();
	}

	public void setPivot(float x, float y) {
		pivotX = PApplet.constrain(x, 0, 1);
		pivotY = PApplet.constrain(y, 0, 1);
	}

	public void draw() {
		/* canvas.loadPixels();
     for (int x = 0; x < canvas.pixels.length; x++) {
     //if( b.pixels[x] == 0x00FFFFFF) {
     if (canvas.pixels[x] == 0x00000000) {
     canvas.pixels[x] = 0xFFFF0000;
     }
     //println(canvas.pixels[x]);
     //}
     }
     canvas.updatePixels();*/
		parentPApplet.pushMatrix();
		parentPApplet.translate(x, y);
		parentPApplet.image(blueprint, -pivotX*width*scaleX, -pivotY*height*scaleY, width*scaleX, height*scaleY);
		if (showPivot) { 
			drawPivot();
		}
		parentPApplet.popMatrix();
	}

	private void drawPivot() {
		parentPApplet.pushStyle();
		parentPApplet.fill(255, 0, 0);
		parentPApplet.noStroke();
		parentPApplet.rectMode(PConstants.CENTER);
		parentPApplet.rect(0, 0, 4, 4);
		parentPApplet.popStyle();
	}

	public void pre() {
		calcBox();
		updateBots();
	}
	
	void updateBots() {
		for(int b=0; b<bots.size(); b++) {
			BuilderBot bot = bots.get(b);
			bot.pre();
		}
	}

	boolean mouseInside() {
		calcBox();
		return (parentPApplet.mouseX > left && parentPApplet.mouseX < right && parentPApplet.mouseY > top && parentPApplet.mouseY < bottom) ? true : false;
	}

	boolean mouseReallyInside() {
		if (mouseInside()) {
			PImage buffer = blueprint.get();
			buffer.resize(width*(int)scaleX, height*(int)scaleY);
			buffer.loadPixels();
			if (buffer.pixels[PApplet.constrain( (parentPApplet.mouseX-(int)left) + (parentPApplet.mouseY-(int)left) * width, 0, buffer.pixels.length-1)] == 0x00000000) {
				buffer.updatePixels();
				return false;
			}
			buffer.updatePixels();
			return true;    
		}
		return false;
	}
}
