package littlerobots.assemblyline;

import java.util.ArrayList;
import java.awt.event.*;
import processing.core.PApplet;
import littlerobots.assemblyline.builderbot.Blueprint;
import littlerobots.assemblyline.builderbot.BuilderBot;
import littlerobots.assemblyline.tweenermatrix.TweenerMatrix;

public class AssemblyLine implements MouseWheelListener {
	private PApplet parent;
	private TweenerMatrix tweenerMatrix;
	private ArrayList<BuilderBot> bots;
	
	public AssemblyLine(PApplet parent, boolean enableTweenerMatrix) {
		
		parent.registerPre(this);
		parent.registerDraw(this);
		parent.registerMouseEvent(this);
		parent.frame.addMouseWheelListener(this);
		
		this.parent = parent;
		bots = new ArrayList<BuilderBot>();
		if(enableTweenerMatrix) {
			installTweenMatrix(false);
		}
		
		bots = new ArrayList<BuilderBot>();
	}

	public void installTweenMatrix(boolean remove) {
		if(!remove && tweenerMatrix != null) {
			tweenerMatrix = new TweenerMatrix();
		} else {
			tweenerMatrix = null;
		}
	}
	
	public BuilderBot addBuilderBot(Blueprint blueprint) {
		BuilderBot newBot = new BuilderBot(parent, blueprint);
		bots.add(newBot);
		return newBot;
	}
	
	public void pre(){
		//Updates TweenMatrix
		if(tweenerMatrix != null) {
			tweenerMatrix.update();
		}
		updateBots();
	}
	
	private void updateBots() {
		for(int b=0; b<bots.size(); b++) {
			BuilderBot bot = bots.get(b);
			bot.pre();
		}
	}
	
	public void draw(){
		drawBots();
	}
	
	private void drawBots() {
		for(int b=0; b<bots.size(); b++) {
			BuilderBot bot = bots.get(b);
			bot.pre();
		}
	}
	
	public void mouseEvent(MouseEvent event) {
		// get the x and y pos of the event
		//int x = event.getX();
		//int y = event.getY();

		switch (event.getID()) {
		case MouseEvent.MOUSE_PRESSED:
			//mousePressed(mouseInside());
			break;
		case MouseEvent.MOUSE_RELEASED:
			//mouseReleased(mouseInside());
			break;
		case MouseEvent.MOUSE_CLICKED:
			//mouseClicked(mouseInside());
			break;
		case MouseEvent.MOUSE_DRAGGED:
			//mouseDragged(mouseInside());
			break;
		case MouseEvent.MOUSE_MOVED:
			//mouseMoved(mouseInside());
			break;
		}
	}
	
	public void mouseWheelMoved(MouseWheelEvent e) {
		//int step = e.getWheelRotation();
		//mouseScrolled(mouseInside(), step);
	}
}
